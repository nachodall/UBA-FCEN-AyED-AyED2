package aed;

import java.util.Scanner;
import java.io.PrintStream;

class Archivos {
    float[] leerVector(Scanner entrada, int largo) {
        return new float[0];
    }

    float[][] leerMatriz(Scanner entrada, int filas, int columnas) {
        return new float[0][0];
    }

    void imprimirPiramide(PrintStream salida, int alto) {
        
    }
}
