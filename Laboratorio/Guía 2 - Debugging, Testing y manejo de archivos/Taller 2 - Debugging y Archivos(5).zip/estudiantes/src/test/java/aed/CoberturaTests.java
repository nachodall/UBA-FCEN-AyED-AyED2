package aed;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

class CoberturaTests {
    Cobertura cobertura = new Cobertura();

    @Test
    void testFizzBuzz() {
        assertEquals("A","B");
    }

    @Test
    void testNumeroCombinatorio() {
        assertTrue(false);
    }

    @Test
    void testRepeticionesConsecutivas() {
        assertTrue(false);
    }
}
